// Simple startup script for Windows
process.env.NODE_ENV = 'development';

import('./server/index.ts')
  .then(() => {
    console.log('Medical Store Management System started successfully!');
    console.log('Open your browser to: http://localhost:5000');
  })
  .catch((error) => {
    console.error('Failed to start server:', error.message);
    console.log('\nTrying alternative method...');
    
    // Alternative: start without vite config
    import('./server/routes.js').catch(() => {
      console.log('Please ensure you have run: npm install');
    });
  });