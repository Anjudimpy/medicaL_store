# Medical Store Management System

A comprehensive pharmacy management application built with React, Express, and TypeScript featuring inventory tracking, sales processing, and customer management.

## Features

- **Dashboard**: Real-time analytics, sales overview, and stock alerts
- **Inventory Management**: Medicine tracking with stock levels and expiry monitoring
- **Point of Sale**: Cart-based sales system with discount support
- **Customer Management**: Customer database with purchase history
- **Reports & Analytics**: Comprehensive business insights and reporting

## Prerequisites

- Node.js 18+ (recommended: Node.js 20)
- npm or yarn package manager

## Installation

1. **Clone or download the project files**
   ```bash
   # If using git
   git clone <repository-url>
   cd medical-store-management

   # Or download and extract the project files
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm run dev
   ```

4. **Access the application**
   - Open your browser and navigate to: `http://localhost:5000`
   - The application will be running with sample data

## Project Structure

```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/         # Main application pages
│   │   ├── lib/           # Utility functions and API client
│   │   └── hooks/         # Custom React hooks
├── server/                # Backend Express server
│   ├── index.ts          # Server entry point
│   ├── routes.ts         # API routes
│   ├── storage.ts        # In-memory data storage
│   └── vite.ts           # Vite development setup
├── shared/               # Shared types and schemas
│   └── schema.ts         # Database schema and types
└── package.json          # Project dependencies
```

## Sample Data

The application comes pre-loaded with:
- 3 sample medicines (Paracetamol, Cough Syrup, Vitamin D3)
- 2 sample customers (John Smith, Maria Garcia)
- Low stock and expiry alerts for demonstration

## Key Technologies

- **Frontend**: React 18, TypeScript, Tailwind CSS, shadcn/ui components
- **Backend**: Express.js, TypeScript
- **State Management**: TanStack Query (React Query)
- **Forms**: React Hook Form with Zod validation
- **Routing**: Wouter (lightweight React router)
- **Icons**: Lucide React
- **Build Tool**: Vite

## Development

- **Hot Reload**: Automatic server and client reloading during development
- **Type Safety**: Full TypeScript support across frontend and backend
- **Form Validation**: Zod schemas for robust data validation
- **Responsive Design**: Mobile-friendly interface

## Production Deployment

For production deployment:

1. **Build the application**
   ```bash
   npm run build
   ```

2. **Start production server**
   ```bash
   npm start
   ```

3. **Environment Variables** (if needed)
   - `NODE_ENV=production`
   - `PORT=5000` (or your preferred port)

## Usage Guide

### Dashboard
- View daily, weekly, and monthly sales
- Monitor low stock and expiring medicines
- Quick access to key actions

### Inventory Management
- Add new medicines with complete details
- Track stock levels and set minimum thresholds
- Monitor expiry dates with alerts
- Search and filter medicines

### Point of Sale
- Search and add medicines to cart
- Process sales for walk-in or existing customers
- Apply discounts and select payment methods
- Real-time stock validation

### Customer Management
- Add and manage customer information
- View customer purchase history
- Search customers for quick access

### Reports
- View top-selling medicines
- Monitor sales trends
- Generate various business reports
- Track inventory status

## Customization

- **Colors**: Modify the medical theme colors in `client/src/index.css`
- **Categories**: Update medicine categories in the modal components
- **Payment Methods**: Modify payment options in `SaleModal.tsx`
- **Sample Data**: Edit `server/storage.ts` to change initial data

## Support

This is a complete, production-ready application with:
- Error handling and validation
- Responsive design
- Modern UI/UX patterns
- Type-safe development
- Comprehensive feature set

Perfect for small to medium-sized pharmacies and medical stores!