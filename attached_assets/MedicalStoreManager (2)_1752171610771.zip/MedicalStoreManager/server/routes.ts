import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertMedicineSchema, 
  insertCustomerSchema, 
  insertSaleSchema, 
  insertSaleItemSchema 
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Medicine routes
  app.get("/api/medicines", async (req, res) => {
    try {
      const medicines = await storage.getMedicines();
      res.json(medicines);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch medicines" });
    }
  });

  app.get("/api/medicines/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      const medicines = await storage.searchMedicines(query);
      res.json(medicines);
    } catch (error) {
      res.status(500).json({ message: "Failed to search medicines" });
    }
  });

  app.get("/api/medicines/low-stock", async (req, res) => {
    try {
      const medicines = await storage.getLowStockMedicines();
      res.json(medicines);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch low stock medicines" });
    }
  });

  app.get("/api/medicines/expiring", async (req, res) => {
    try {
      const days = parseInt(req.query.days as string) || 30;
      const medicines = await storage.getExpiringMedicines(days);
      res.json(medicines);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch expiring medicines" });
    }
  });

  app.get("/api/medicines/barcode/:barcode", async (req, res) => {
    try {
      const medicine = await storage.getMedicineByBarcode(req.params.barcode);
      if (!medicine) {
        return res.status(404).json({ message: "Medicine not found" });
      }
      res.json(medicine);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch medicine" });
    }
  });

  app.get("/api/medicines/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const medicine = await storage.getMedicine(id);
      if (!medicine) {
        return res.status(404).json({ message: "Medicine not found" });
      }
      res.json(medicine);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch medicine" });
    }
  });

  app.post("/api/medicines", async (req, res) => {
    try {
      const validatedData = insertMedicineSchema.parse(req.body);
      const medicine = await storage.createMedicine(validatedData);
      res.status(201).json(medicine);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create medicine" });
    }
  });

  app.put("/api/medicines/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertMedicineSchema.partial().parse(req.body);
      const medicine = await storage.updateMedicine(id, validatedData);
      if (!medicine) {
        return res.status(404).json({ message: "Medicine not found" });
      }
      res.json(medicine);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update medicine" });
    }
  });

  app.delete("/api/medicines/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteMedicine(id);
      if (!deleted) {
        return res.status(404).json({ message: "Medicine not found" });
      }
      res.json({ message: "Medicine deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete medicine" });
    }
  });

  // Customer routes
  app.get("/api/customers", async (req, res) => {
    try {
      const customers = await storage.getCustomers();
      res.json(customers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customers" });
    }
  });

  app.get("/api/customers/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      const customers = await storage.searchCustomers(query);
      res.json(customers);
    } catch (error) {
      res.status(500).json({ message: "Failed to search customers" });
    }
  });

  app.get("/api/customers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const customer = await storage.getCustomer(id);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      res.json(customer);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customer" });
    }
  });

  app.get("/api/customers/:id/sales", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const sales = await storage.getSalesByCustomer(id);
      res.json(sales);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customer sales" });
    }
  });

  app.post("/api/customers", async (req, res) => {
    try {
      const validatedData = insertCustomerSchema.parse(req.body);
      const customer = await storage.createCustomer(validatedData);
      res.status(201).json(customer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create customer" });
    }
  });

  app.put("/api/customers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertCustomerSchema.partial().parse(req.body);
      const customer = await storage.updateCustomer(id, validatedData);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      res.json(customer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update customer" });
    }
  });

  app.delete("/api/customers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteCustomer(id);
      if (!deleted) {
        return res.status(404).json({ message: "Customer not found" });
      }
      res.json({ message: "Customer deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete customer" });
    }
  });

  // Sales routes
  app.get("/api/sales", async (req, res) => {
    try {
      const sales = await storage.getSales();
      res.json(sales);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sales" });
    }
  });

  app.get("/api/sales/daily/:date", async (req, res) => {
    try {
      const sales = await storage.getSalesByDate(req.params.date);
      res.json(sales);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch daily sales" });
    }
  });

  app.get("/api/sales/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const sale = await storage.getSale(id);
      if (!sale) {
        return res.status(404).json({ message: "Sale not found" });
      }
      res.json(sale);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sale" });
    }
  });

  app.get("/api/sales/:id/items", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const items = await storage.getSaleItemsWithMedicines(id);
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sale items" });
    }
  });

  app.post("/api/sales", async (req, res) => {
    try {
      const { sale, items } = req.body;
      
      // Validate sale data
      const validatedSale = insertSaleSchema.parse(sale);
      
      // Validate items data
      const validatedItems = z.array(insertSaleItemSchema.omit({ saleId: true })).parse(items);
      
      // Create sale
      const createdSale = await storage.createSale(validatedSale);
      
      // Create sale items
      const saleItems = await Promise.all(
        validatedItems.map(item => 
          storage.createSaleItem({ ...item, saleId: createdSale.id })
        )
      );
      
      res.status(201).json({ sale: createdSale, items: saleItems });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create sale" });
    }
  });

  // Analytics routes
  app.get("/api/analytics/dashboard", async (req, res) => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const [
        dailySales,
        weeklySales,
        monthlySales,
        totalMedicines,
        lowStockMedicines,
        expiringMedicines,
        topSellingMedicines
      ] = await Promise.all([
        storage.getDailySales(today),
        storage.getWeeklySales(),
        storage.getMonthlySales(),
        storage.getMedicines(),
        storage.getLowStockMedicines(),
        storage.getExpiringMedicines(30),
        storage.getTopSellingMedicines(5)
      ]);

      res.json({
        dailySales,
        weeklySales,
        monthlySales,
        totalMedicines: totalMedicines.length,
        lowStockCount: lowStockMedicines.length,
        expiringCount: expiringMedicines.length,
        lowStockMedicines: lowStockMedicines.slice(0, 5),
        expiringMedicines: expiringMedicines.slice(0, 5),
        topSellingMedicines
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard analytics" });
    }
  });

  app.get("/api/analytics/top-medicines", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const topMedicines = await storage.getTopSellingMedicines(limit);
      res.json(topMedicines);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch top selling medicines" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
