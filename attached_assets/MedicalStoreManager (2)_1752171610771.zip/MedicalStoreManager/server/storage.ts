import { 
  medicines, customers, sales, saleItems, users,
  type Medicine, type InsertMedicine,
  type Customer, type InsertCustomer,
  type Sale, type InsertSale,
  type SaleItem, type InsertSaleItem,
  type User, type InsertUser 
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Medicine methods
  getMedicines(): Promise<Medicine[]>;
  getMedicine(id: number): Promise<Medicine | undefined>;
  getMedicineByBarcode(barcode: string): Promise<Medicine | undefined>;
  createMedicine(medicine: InsertMedicine): Promise<Medicine>;
  updateMedicine(id: number, medicine: Partial<InsertMedicine>): Promise<Medicine | undefined>;
  deleteMedicine(id: number): Promise<boolean>;
  searchMedicines(query: string): Promise<Medicine[]>;
  getLowStockMedicines(): Promise<Medicine[]>;
  getExpiringMedicines(days: number): Promise<Medicine[]>;

  // Customer methods
  getCustomers(): Promise<Customer[]>;
  getCustomer(id: number): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: number, customer: Partial<InsertCustomer>): Promise<Customer | undefined>;
  deleteCustomer(id: number): Promise<boolean>;
  searchCustomers(query: string): Promise<Customer[]>;

  // Sales methods
  getSales(): Promise<Sale[]>;
  getSale(id: number): Promise<Sale | undefined>;
  createSale(sale: InsertSale): Promise<Sale>;
  getSalesByDate(date: string): Promise<Sale[]>;
  getSalesByCustomer(customerId: number): Promise<Sale[]>;

  // Sale items methods
  getSaleItems(saleId: number): Promise<SaleItem[]>;
  createSaleItem(saleItem: InsertSaleItem): Promise<SaleItem>;
  getSaleItemsWithMedicines(saleId: number): Promise<(SaleItem & { medicine: Medicine })[]>;

  // Analytics methods
  getDailySales(date: string): Promise<{ totalSales: number; totalAmount: string }>;
  getWeeklySales(): Promise<{ totalSales: number; totalAmount: string }>;
  getMonthlySales(): Promise<{ totalSales: number; totalAmount: string }>;
  getTopSellingMedicines(limit: number): Promise<(Medicine & { totalSold: number })[]>;
}

export class MemStorage implements IStorage {
  private medicines: Map<number, Medicine>;
  private customers: Map<number, Customer>;
  private sales: Map<number, Sale>;
  private saleItems: Map<number, SaleItem>;
  private users: Map<number, User>;
  private currentMedicineId: number;
  private currentCustomerId: number;
  private currentSaleId: number;
  private currentSaleItemId: number;
  private currentUserId: number;

  constructor() {
    this.medicines = new Map();
    this.customers = new Map();
    this.sales = new Map();
    this.saleItems = new Map();
    this.users = new Map();
    this.currentMedicineId = 1;
    this.currentCustomerId = 1;
    this.currentSaleId = 1;
    this.currentSaleItemId = 1;
    this.currentUserId = 1;

    // Initialize with some sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample medicines
    const sampleMedicines: InsertMedicine[] = [
      {
        name: "Paracetamol 500mg",
        genericName: "Acetaminophen",
        manufacturer: "PharmaCorp",
        category: "tablets",
        dosage: "500mg",
        price: "2.50",
        costPrice: "1.50",
        stock: 15,
        minStock: 20,
        barcode: "123456789001",
        expiryDate: new Date("2025-12-31"),
        batchNumber: "PC001",
        description: "Pain relief and fever reducer"
      },
      {
        name: "Cough Syrup",
        genericName: "Dextromethorphan",
        manufacturer: "MediPharm",
        category: "syrups",
        dosage: "100ml",
        price: "8.75",
        costPrice: "5.25",
        stock: 7,
        minStock: 10,
        barcode: "123456789002",
        expiryDate: new Date("2024-12-25"),
        batchNumber: "MP002",
        description: "Cough suppressant"
      },
      {
        name: "Vitamin D3",
        genericName: "Cholecalciferol",
        manufacturer: "VitaHealth",
        category: "supplements",
        dosage: "1000 IU",
        price: "12.99",
        costPrice: "8.00",
        stock: 8,
        minStock: 15,
        barcode: "123456789003",
        expiryDate: new Date("2026-06-30"),
        batchNumber: "VH003",
        description: "Vitamin D supplement"
      }
    ];

    sampleMedicines.forEach(medicine => {
      this.createMedicine(medicine);
    });

    // Sample customers
    const sampleCustomers: InsertCustomer[] = [
      {
        name: "John Smith",
        phone: "+1234567890",
        email: "john.smith@email.com",
        address: "123 Main St, City"
      },
      {
        name: "Maria Garcia",
        phone: "+1234567891",
        email: "maria.garcia@email.com",
        address: "456 Oak Ave, City"
      }
    ];

    sampleCustomers.forEach(customer => {
      this.createCustomer(customer);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Medicine methods
  async getMedicines(): Promise<Medicine[]> {
    return Array.from(this.medicines.values()).filter(m => m.isActive);
  }

  async getMedicine(id: number): Promise<Medicine | undefined> {
    const medicine = this.medicines.get(id);
    return medicine?.isActive ? medicine : undefined;
  }

  async getMedicineByBarcode(barcode: string): Promise<Medicine | undefined> {
    return Array.from(this.medicines.values()).find(
      m => m.barcode === barcode && m.isActive
    );
  }

  async createMedicine(insertMedicine: InsertMedicine): Promise<Medicine> {
    const id = this.currentMedicineId++;
    const medicine: Medicine = { 
      ...insertMedicine, 
      id, 
      isActive: true,
      stock: insertMedicine.stock || 0
    };
    this.medicines.set(id, medicine);
    return medicine;
  }

  async updateMedicine(id: number, medicine: Partial<InsertMedicine>): Promise<Medicine | undefined> {
    const existing = this.medicines.get(id);
    if (!existing || !existing.isActive) return undefined;
    
    const updated = { ...existing, ...medicine };
    this.medicines.set(id, updated);
    return updated;
  }

  async deleteMedicine(id: number): Promise<boolean> {
    const medicine = this.medicines.get(id);
    if (!medicine) return false;
    
    medicine.isActive = false;
    this.medicines.set(id, medicine);
    return true;
  }

  async searchMedicines(query: string): Promise<Medicine[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.medicines.values()).filter(m => 
      m.isActive && (
        m.name.toLowerCase().includes(lowerQuery) ||
        m.genericName?.toLowerCase().includes(lowerQuery) ||
        m.manufacturer.toLowerCase().includes(lowerQuery) ||
        m.barcode?.includes(query)
      )
    );
  }

  async getLowStockMedicines(): Promise<Medicine[]> {
    return Array.from(this.medicines.values()).filter(m => 
      m.isActive && m.stock <= m.minStock
    );
  }

  async getExpiringMedicines(days: number): Promise<Medicine[]> {
    const targetDate = new Date();
    targetDate.setDate(targetDate.getDate() + days);
    
    return Array.from(this.medicines.values()).filter(m => 
      m.isActive && new Date(m.expiryDate) <= targetDate
    );
  }

  // Customer methods
  async getCustomers(): Promise<Customer[]> {
    return Array.from(this.customers.values()).filter(c => c.isActive);
  }

  async getCustomer(id: number): Promise<Customer | undefined> {
    const customer = this.customers.get(id);
    return customer?.isActive ? customer : undefined;
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const id = this.currentCustomerId++;
    const customer: Customer = { ...insertCustomer, id, isActive: true };
    this.customers.set(id, customer);
    return customer;
  }

  async updateCustomer(id: number, customer: Partial<InsertCustomer>): Promise<Customer | undefined> {
    const existing = this.customers.get(id);
    if (!existing || !existing.isActive) return undefined;
    
    const updated = { ...existing, ...customer };
    this.customers.set(id, updated);
    return updated;
  }

  async deleteCustomer(id: number): Promise<boolean> {
    const customer = this.customers.get(id);
    if (!customer) return false;
    
    customer.isActive = false;
    this.customers.set(id, customer);
    return true;
  }

  async searchCustomers(query: string): Promise<Customer[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.customers.values()).filter(c => 
      c.isActive && (
        c.name.toLowerCase().includes(lowerQuery) ||
        c.phone?.includes(query) ||
        c.email?.toLowerCase().includes(lowerQuery)
      )
    );
  }

  // Sales methods
  async getSales(): Promise<Sale[]> {
    return Array.from(this.sales.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getSale(id: number): Promise<Sale | undefined> {
    return this.sales.get(id);
  }

  async createSale(insertSale: InsertSale): Promise<Sale> {
    const id = this.currentSaleId++;
    const sale: Sale = { 
      ...insertSale, 
      id, 
      createdAt: new Date()
    };
    this.sales.set(id, sale);
    return sale;
  }

  async getSalesByDate(date: string): Promise<Sale[]> {
    const targetDate = new Date(date);
    return Array.from(this.sales.values()).filter(sale => {
      const saleDate = new Date(sale.createdAt);
      return saleDate.toDateString() === targetDate.toDateString();
    });
  }

  async getSalesByCustomer(customerId: number): Promise<Sale[]> {
    return Array.from(this.sales.values()).filter(sale => 
      sale.customerId === customerId
    ).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  // Sale items methods
  async getSaleItems(saleId: number): Promise<SaleItem[]> {
    return Array.from(this.saleItems.values()).filter(item => 
      item.saleId === saleId
    );
  }

  async createSaleItem(insertSaleItem: InsertSaleItem): Promise<SaleItem> {
    const id = this.currentSaleItemId++;
    const saleItem: SaleItem = { ...insertSaleItem, id };
    this.saleItems.set(id, saleItem);
    
    // Update medicine stock
    const medicine = this.medicines.get(insertSaleItem.medicineId);
    if (medicine) {
      medicine.stock = Math.max(0, medicine.stock - insertSaleItem.quantity);
      this.medicines.set(medicine.id, medicine);
    }
    
    return saleItem;
  }

  async getSaleItemsWithMedicines(saleId: number): Promise<(SaleItem & { medicine: Medicine })[]> {
    const items = await this.getSaleItems(saleId);
    return items.map(item => {
      const medicine = this.medicines.get(item.medicineId);
      return { ...item, medicine: medicine! };
    }).filter(item => item.medicine);
  }

  // Analytics methods
  async getDailySales(date: string): Promise<{ totalSales: number; totalAmount: string }> {
    const dailySales = await this.getSalesByDate(date);
    const totalSales = dailySales.length;
    const totalAmount = dailySales.reduce((sum, sale) => 
      sum + parseFloat(sale.finalAmount), 0
    ).toFixed(2);
    
    return { totalSales, totalAmount };
  }

  async getWeeklySales(): Promise<{ totalSales: number; totalAmount: string }> {
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    
    const weeklySales = Array.from(this.sales.values()).filter(sale => 
      new Date(sale.createdAt) >= weekAgo
    );
    
    const totalSales = weeklySales.length;
    const totalAmount = weeklySales.reduce((sum, sale) => 
      sum + parseFloat(sale.finalAmount), 0
    ).toFixed(2);
    
    return { totalSales, totalAmount };
  }

  async getMonthlySales(): Promise<{ totalSales: number; totalAmount: string }> {
    const monthAgo = new Date();
    monthAgo.setDate(monthAgo.getDate() - 30);
    
    const monthlySales = Array.from(this.sales.values()).filter(sale => 
      new Date(sale.createdAt) >= monthAgo
    );
    
    const totalSales = monthlySales.length;
    const totalAmount = monthlySales.reduce((sum, sale) => 
      sum + parseFloat(sale.finalAmount), 0
    ).toFixed(2);
    
    return { totalSales, totalAmount };
  }

  async getTopSellingMedicines(limit: number): Promise<(Medicine & { totalSold: number })[]> {
    const medicineStats = new Map<number, number>();
    
    Array.from(this.saleItems.values()).forEach(item => {
      const current = medicineStats.get(item.medicineId) || 0;
      medicineStats.set(item.medicineId, current + item.quantity);
    });
    
    const topMedicines = Array.from(medicineStats.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, limit)
      .map(([medicineId, totalSold]) => {
        const medicine = this.medicines.get(medicineId);
        return medicine ? { ...medicine, totalSold } : null;
      })
      .filter(item => item !== null) as (Medicine & { totalSold: number })[];
    
    return topMedicines;
  }
}

export const storage = new MemStorage();
