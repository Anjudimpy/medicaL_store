import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Plus, Search, Edit, Trash2, AlertTriangle, Clock } from "lucide-react";
import { formatCurrency, formatDate, isExpiringSoon, isExpired, getStockStatus } from "@/lib/utils";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import AddMedicineModal from "@/components/inventory/AddMedicineModal";
import EditMedicineModal from "@/components/inventory/EditMedicineModal";
import type { Medicine } from "@shared/schema";

export default function Inventory() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingMedicine, setEditingMedicine] = useState<Medicine | null>(null);
  const { toast } = useToast();

  const { data: medicines = [], isLoading } = useQuery({
    queryKey: ["/api/medicines"],
  });

  const { data: searchResults = [] } = useQuery({
    queryKey: ["/api/medicines/search", searchQuery],
    enabled: searchQuery.length > 0,
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/medicines/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/medicines"] });
      toast({
        title: "Success",
        description: "Medicine deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete medicine",
        variant: "destructive",
      });
    },
  });

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this medicine?")) {
      deleteMutation.mutate(id);
    }
  };

  const displayMedicines = searchQuery ? searchResults : medicines;

  const getStockBadge = (medicine: Medicine) => {
    const status = getStockStatus(medicine.stock, medicine.minStock);
    const colors = {
      out: "bg-red-100 text-red-800",
      low: "bg-orange-100 text-orange-800",
      normal: "bg-green-100 text-green-800"
    };
    const labels = {
      out: "Out of Stock",
      low: "Low Stock",
      normal: "In Stock"
    };
    
    return (
      <Badge className={colors[status]}>
        {labels[status]}
      </Badge>
    );
  };

  const getExpiryBadge = (expiryDate: string) => {
    if (isExpired(expiryDate)) {
      return <Badge className="bg-red-100 text-red-800">Expired</Badge>;
    }
    if (isExpiringSoon(expiryDate)) {
      return <Badge className="bg-orange-100 text-orange-800">Expiring Soon</Badge>;
    }
    return null;
  };

  if (isLoading) {
    return <div className="p-6">Loading inventory...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header Actions */}
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search medicines..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 w-80"
            />
          </div>
        </div>
        <Button onClick={() => setShowAddModal(true)} className="bg-medical-green hover:bg-green-700">
          <Plus className="h-4 w-4 mr-2" />
          Add Medicine
        </Button>
      </div>

      {/* Inventory Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{medicines.length}</div>
            <div className="text-sm text-gray-500">Total Medicines</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-warning-orange">
              {medicines.filter((m: Medicine) => getStockStatus(m.stock, m.minStock) === 'low').length}
            </div>
            <div className="text-sm text-gray-500">Low Stock</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-alert-red">
              {medicines.filter((m: Medicine) => getStockStatus(m.stock, m.minStock) === 'out').length}
            </div>
            <div className="text-sm text-gray-500">Out of Stock</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-warning-orange">
              {medicines.filter((m: Medicine) => isExpiringSoon(m.expiryDate)).length}
            </div>
            <div className="text-sm text-gray-500">Expiring Soon</div>
          </CardContent>
        </Card>
      </div>

      {/* Medicines Table */}
      <Card>
        <CardHeader>
          <CardTitle>Medicine Inventory</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Medicine</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Stock</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Expiry Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {displayMedicines.map((medicine: Medicine) => (
                <TableRow key={medicine.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{medicine.name}</div>
                      <div className="text-sm text-gray-500">{medicine.genericName}</div>
                      <div className="text-xs text-gray-400">{medicine.manufacturer}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{medicine.category}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <span>{medicine.stock}</span>
                      {medicine.stock <= medicine.minStock && (
                        <AlertTriangle className="h-4 w-4 text-warning-orange" />
                      )}
                    </div>
                  </TableCell>
                  <TableCell>{formatCurrency(medicine.price)}</TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <span>{formatDate(medicine.expiryDate)}</span>
                      {isExpiringSoon(medicine.expiryDate) && (
                        <Clock className="h-4 w-4 text-warning-orange" />
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col space-y-1">
                      {getStockBadge(medicine)}
                      {getExpiryBadge(medicine.expiryDate)}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setEditingMedicine(medicine)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(medicine.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          
          {displayMedicines.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              {searchQuery ? "No medicines found" : "No medicines in inventory"}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modals */}
      {showAddModal && (
        <AddMedicineModal
          open={showAddModal}
          onClose={() => setShowAddModal(false)}
        />
      )}

      {editingMedicine && (
        <EditMedicineModal
          medicine={editingMedicine}
          open={!!editingMedicine}
          onClose={() => setEditingMedicine(null)}
        />
      )}
    </div>
  );
}
