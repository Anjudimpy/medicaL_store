import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  DollarSign, 
  PillBottle, 
  AlertTriangle, 
  Clock,
  Receipt,
  Tablets,
  Syringe,
  FlaskRound,
  Package2,
  Bandage,
  Heart
} from "lucide-react";
import { formatCurrency, formatDateTime, getDaysUntilExpiry } from "@/lib/utils";

export default function Dashboard() {
  const { data: analytics, isLoading } = useQuery({
    queryKey: ["/api/analytics/dashboard"],
  });

  const { data: recentSales } = useQuery({
    queryKey: ["/api/sales"],
  });

  if (isLoading) {
    return <div className="p-6">Loading dashboard...</div>;
  }

  const stats = [
    {
      title: "Today's Sales",
      value: analytics?.dailySales ? formatCurrency(analytics.dailySales.totalAmount) : "$0",
      subtitle: `${analytics?.dailySales?.totalSales || 0} transactions`,
      icon: DollarSign,
      bgColor: "bg-green-100",
      iconColor: "text-medical-green"
    },
    {
      title: "Total Medicines",
      value: analytics?.totalMedicines?.toString() || "0",
      subtitle: "Active inventory",
      icon: PillBottle,
      bgColor: "bg-blue-100",
      iconColor: "text-trust-blue"
    },
    {
      title: "Low Stock Items",
      value: analytics?.lowStockCount?.toString() || "0",
      subtitle: "Needs attention",
      icon: AlertTriangle,
      bgColor: "bg-orange-100",
      iconColor: "text-warning-orange"
    },
    {
      title: "Expired Soon",
      value: analytics?.expiringCount?.toString() || "0",
      subtitle: "Within 30 days",
      icon: Clock,
      bgColor: "bg-red-100",
      iconColor: "text-alert-red"
    }
  ];

  const categories = [
    { name: "Tablets", count: "342 items", icon: Tablets, bgColor: "bg-medical-green" },
    { name: "Injections", count: "87 items", icon: Syringe, bgColor: "bg-trust-blue" },
    { name: "Syrups", count: "156 items", icon: FlaskRound, bgColor: "bg-purple-500" },
    { name: "Capsules", count: "234 items", icon: Package2, bgColor: "bg-orange-500" },
    { name: "External", count: "98 items", icon: Bandage, bgColor: "bg-pink-500" },
    { name: "Supplements", count: "128 items", icon: Heart, bgColor: "bg-teal-500" }
  ];

  return (
    <div className="space-y-8">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-sm text-gray-500 mt-1">{stat.subtitle}</p>
                </div>
                <div className={`w-12 h-12 ${stat.bgColor} rounded-lg flex items-center justify-center`}>
                  <stat.icon className={`${stat.iconColor} text-xl`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Transactions */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Recent Transactions</CardTitle>
                <Button variant="ghost" className="text-medical-green hover:text-green-700">
                  View All
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentSales?.slice(0, 5).map((sale: any) => (
                  <div key={sale.id} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-b-0">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                        <Receipt className="text-medical-green" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">
                          {sale.customerName || `Customer #${sale.customerId}`}
                        </p>
                        <p className="text-sm text-gray-500">
                          Sale #{sale.id}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-gray-900">
                        {formatCurrency(sale.finalAmount)}
                      </p>
                      <p className="text-sm text-gray-500">
                        {formatDateTime(sale.createdAt)}
                      </p>
                    </div>
                  </div>
                )) || (
                  <p className="text-gray-500 text-center py-8">No recent transactions</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Alerts & Quick Actions */}
        <div className="space-y-6">
          {/* Stock Alerts */}
          <Card>
            <CardHeader>
              <CardTitle>Stock Alerts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analytics?.lowStockMedicines?.map((medicine: any) => (
                  <div key={medicine.id} className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-warning-orange rounded-full mt-2"></div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">{medicine.name}</p>
                      <p className="text-sm text-gray-500">Only {medicine.stock} left</p>
                    </div>
                    <Button variant="ghost" size="sm" className="text-medical-green hover:text-green-700">
                      Reorder
                    </Button>
                  </div>
                ))}
                
                {analytics?.expiringMedicines?.map((medicine: any) => (
                  <div key={`exp-${medicine.id}`} className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-alert-red rounded-full mt-2"></div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">{medicine.name}</p>
                      <p className="text-sm text-gray-500">
                        Expires in {getDaysUntilExpiry(medicine.expiryDate)} days
                      </p>
                    </div>
                    <Button variant="ghost" size="sm" className="text-medical-green hover:text-green-700">
                      Action
                    </Button>
                  </div>
                ))}
                
                {(!analytics?.lowStockMedicines?.length && !analytics?.expiringMedicines?.length) && (
                  <p className="text-gray-500 text-center py-4">No alerts</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Button className="w-full bg-medical-green hover:bg-green-700">
                  <PillBottle className="mr-3 h-4 w-4" />
                  Add New Medicine
                </Button>
                <Button className="w-full bg-trust-blue hover:bg-blue-700">
                  <Receipt className="mr-3 h-4 w-4" />
                  Process Sale
                </Button>
                <Button variant="outline" className="w-full">
                  <Clock className="mr-3 h-4 w-4" />
                  Generate Report
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Medicine Categories Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Medicine Categories</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((category, index) => (
              <div
                key={index}
                className="text-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors"
              >
                <div className={`w-12 h-12 ${category.bgColor} rounded-lg flex items-center justify-center mx-auto mb-3`}>
                  <category.icon className="text-white text-xl" />
                </div>
                <p className="font-medium text-gray-900">{category.name}</p>
                <p className="text-sm text-gray-500">{category.count}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
