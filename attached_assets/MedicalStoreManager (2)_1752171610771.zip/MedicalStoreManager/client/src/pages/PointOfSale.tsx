import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Search, Plus, Minus, Trash2, ShoppingCart } from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import SaleModal from "@/components/sales/SaleModal";
import type { Medicine } from "@shared/schema";

interface CartItem {
  medicine: Medicine;
  quantity: number;
  total: number;
}

export default function PointOfSale() {
  const [searchQuery, setSearchQuery] = useState("");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showSaleModal, setShowSaleModal] = useState(false);

  const { data: medicines = [] } = useQuery({
    queryKey: ["/api/medicines"],
  });

  const { data: searchResults = [] } = useQuery({
    queryKey: ["/api/medicines/search", searchQuery],
    enabled: searchQuery.length > 0,
  });

  const addToCart = (medicine: Medicine) => {
    const existingItem = cart.find(item => item.medicine.id === medicine.id);
    
    if (existingItem) {
      if (existingItem.quantity < medicine.stock) {
        updateCartQuantity(medicine.id, existingItem.quantity + 1);
      }
    } else {
      if (medicine.stock > 0) {
        const newItem: CartItem = {
          medicine,
          quantity: 1,
          total: parseFloat(medicine.price)
        };
        setCart([...cart, newItem]);
      }
    }
  };

  const updateCartQuantity = (medicineId: number, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeFromCart(medicineId);
      return;
    }

    setCart(cart.map(item => {
      if (item.medicine.id === medicineId) {
        const maxQuantity = Math.min(newQuantity, item.medicine.stock);
        return {
          ...item,
          quantity: maxQuantity,
          total: maxQuantity * parseFloat(item.medicine.price)
        };
      }
      return item;
    }));
  };

  const removeFromCart = (medicineId: number) => {
    setCart(cart.filter(item => item.medicine.id !== medicineId));
  };

  const clearCart = () => {
    setCart([]);
  };

  const getCartTotal = () => {
    return cart.reduce((total, item) => total + item.total, 0);
  };

  const getCartItemCount = () => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  };

  const displayMedicines = searchQuery ? searchResults : medicines.slice(0, 20);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Medicine Search & Selection */}
      <div className="lg:col-span-2 space-y-6">
        {/* Search */}
        <Card>
          <CardHeader>
            <CardTitle>Search Medicines</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search by name, generic name, or barcode..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardContent>
        </Card>

        {/* Medicine Grid */}
        <Card>
          <CardHeader>
            <CardTitle>Available Medicines</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
              {displayMedicines.map((medicine: Medicine) => (
                <div
                  key={medicine.id}
                  className="border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => addToCart(medicine)}
                >
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">{medicine.name}</h3>
                      <p className="text-sm text-gray-500">{medicine.genericName}</p>
                      <p className="text-xs text-gray-400">{medicine.manufacturer}</p>
                    </div>
                    <Badge variant="outline">{medicine.category}</Badge>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="text-lg font-bold text-medical-green">
                      {formatCurrency(medicine.price)}
                    </div>
                    <div className="text-sm text-gray-500">
                      Stock: {medicine.stock}
                    </div>
                  </div>
                  
                  {medicine.stock === 0 && (
                    <Badge className="mt-2 bg-red-100 text-red-800">Out of Stock</Badge>
                  )}
                </div>
              ))}
            </div>
            
            {displayMedicines.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                {searchQuery ? "No medicines found" : "Start typing to search medicines"}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Shopping Cart */}
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="flex items-center">
                <ShoppingCart className="h-5 w-5 mr-2" />
                Cart ({getCartItemCount()})
              </CardTitle>
              {cart.length > 0 && (
                <Button variant="ghost" size="sm" onClick={clearCart}>
                  Clear All
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {cart.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                Cart is empty
              </div>
            ) : (
              <div className="space-y-4">
                {cart.map((item) => (
                  <div key={item.medicine.id} className="border rounded-lg p-3">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex-1">
                        <h4 className="font-medium text-sm">{item.medicine.name}</h4>
                        <p className="text-xs text-gray-500">{item.medicine.dosage}</p>
                        <p className="text-xs text-medical-green">
                          {formatCurrency(item.medicine.price)} each
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeFromCart(item.medicine.id)}
                        className="text-red-600 hover:text-red-700 p-1"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateCartQuantity(item.medicine.id, item.quantity - 1)}
                          className="h-8 w-8 p-0"
                        >
                          <Minus className="h-3 w-3" />
                        </Button>
                        <span className="w-8 text-center">{item.quantity}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateCartQuantity(item.medicine.id, item.quantity + 1)}
                          disabled={item.quantity >= item.medicine.stock}
                          className="h-8 w-8 p-0"
                        >
                          <Plus className="h-3 w-3" />
                        </Button>
                      </div>
                      <div className="font-medium">
                        {formatCurrency(item.total)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Cart Summary */}
        {cart.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between text-lg font-bold">
                <span>Total:</span>
                <span>{formatCurrency(getCartTotal())}</span>
              </div>
              
              <Button 
                className="w-full bg-medical-green hover:bg-green-700"
                onClick={() => setShowSaleModal(true)}
              >
                Proceed to Checkout
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Sale Modal */}
      {showSaleModal && (
        <SaleModal
          cart={cart}
          total={getCartTotal()}
          open={showSaleModal}
          onClose={() => setShowSaleModal(false)}
          onSuccess={() => {
            setShowSaleModal(false);
            clearCart();
          }}
        />
      )}
    </div>
  );
}
