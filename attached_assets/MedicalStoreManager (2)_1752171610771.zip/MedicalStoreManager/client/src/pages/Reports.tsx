import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  BarChart3, 
  TrendingUp, 
  Calendar, 
  Download,
  DollarSign,
  Package,
  Users,
  FileText
} from "lucide-react";
import { formatCurrency, formatDateTime } from "@/lib/utils";

export default function Reports() {
  const { data: analytics } = useQuery({
    queryKey: ["/api/analytics/dashboard"],
  });

  const { data: topMedicines = [] } = useQuery({
    queryKey: ["/api/analytics/top-medicines"],
  });

  const { data: recentSales = [] } = useQuery({
    queryKey: ["/api/sales"],
  });

  const { data: lowStockMedicines = [] } = useQuery({
    queryKey: ["/api/medicines/low-stock"],
  });

  return (
    <div className="space-y-6">
      {/* Report Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Reports & Analytics</h1>
          <p className="text-gray-600">Comprehensive insights into your pharmacy operations</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Calendar className="h-4 w-4 mr-2" />
            Date Range
          </Button>
          <Button className="bg-medical-green hover:bg-green-700">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Daily Revenue</p>
                <p className="text-2xl font-bold text-gray-900">
                  {analytics?.dailySales ? formatCurrency(analytics.dailySales.totalAmount) : "$0"}
                </p>
                <p className="text-sm text-green-600 mt-1">
                  <TrendingUp className="inline h-3 w-3 mr-1" />
                  +12% from yesterday
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <DollarSign className="text-medical-green text-xl" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Weekly Sales</p>
                <p className="text-2xl font-bold text-gray-900">
                  {analytics?.weeklySales ? formatCurrency(analytics.weeklySales.totalAmount) : "$0"}
                </p>
                <p className="text-sm text-blue-600 mt-1">
                  {analytics?.weeklySales?.totalSales || 0} transactions
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <BarChart3 className="text-trust-blue text-xl" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Monthly Revenue</p>
                <p className="text-2xl font-bold text-gray-900">
                  {analytics?.monthlySales ? formatCurrency(analytics.monthlySales.totalAmount) : "$0"}
                </p>
                <p className="text-sm text-green-600 mt-1">
                  {analytics?.monthlySales?.totalSales || 0} total sales
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="text-purple-600 text-xl" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Medicines</p>
                <p className="text-2xl font-bold text-gray-900">
                  {analytics?.totalMedicines || 0}
                </p>
                <p className="text-sm text-orange-600 mt-1">
                  {analytics?.lowStockCount || 0} low stock
                </p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <Package className="text-warning-orange text-xl" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Reports Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Selling Medicines */}
        <Card>
          <CardHeader>
            <CardTitle>Top Selling Medicines</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Medicine</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Units Sold</TableHead>
                  <TableHead>Revenue</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {topMedicines.map((medicine: any) => (
                  <TableRow key={medicine.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{medicine.name}</div>
                        <div className="text-sm text-gray-500">{medicine.manufacturer}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{medicine.category}</Badge>
                    </TableCell>
                    <TableCell className="font-medium">{medicine.totalSold}</TableCell>
                    <TableCell className="font-medium">
                      {formatCurrency(medicine.totalSold * parseFloat(medicine.price))}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            
            {topMedicines.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                No sales data available
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Sales */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Sales Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentSales.slice(0, 8).map((sale: any) => (
                <div key={sale.id} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-b-0">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                      <FileText className="text-medical-green h-4 w-4" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">
                        {sale.customerName || `Customer #${sale.customerId}`}
                      </p>
                      <p className="text-xs text-gray-500">
                        {formatDateTime(sale.createdAt)}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-sm">{formatCurrency(sale.finalAmount)}</p>
                    <p className="text-xs text-gray-500">{sale.paymentMethod}</p>
                  </div>
                </div>
              ))}
              
              {recentSales.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  No recent sales
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Low Stock Report */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Package className="h-5 w-5 mr-2 text-warning-orange" />
              Low Stock Alert
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {lowStockMedicines.map((medicine: any) => (
                <div key={medicine.id} className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                  <div>
                    <p className="font-medium text-sm">{medicine.name}</p>
                    <p className="text-xs text-gray-500">{medicine.category}</p>
                  </div>
                  <div className="text-right">
                    <Badge className="bg-orange-100 text-orange-800">
                      {medicine.stock} left
                    </Badge>
                    <p className="text-xs text-gray-500 mt-1">
                      Min: {medicine.minStock}
                    </p>
                  </div>
                </div>
              ))}
              
              {lowStockMedicines.length === 0 && (
                <div className="text-center py-4 text-gray-500">
                  All medicines are adequately stocked
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Quick Report Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Generate Reports</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="outline" className="w-full justify-start">
              <FileText className="h-4 w-4 mr-2" />
              Daily Sales Report
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <Package className="h-4 w-4 mr-2" />
              Inventory Status Report
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <Users className="h-4 w-4 mr-2" />
              Customer Analysis Report
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <TrendingUp className="h-4 w-4 mr-2" />
              Financial Summary Report
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <Calendar className="h-4 w-4 mr-2" />
              Monthly Performance Report
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
