import { useState } from "react";
import { Search, Bell, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";

const pageNames = {
  "/": "Dashboard",
  "/inventory": "Inventory Management",
  "/pos": "Point of Sale",
  "/customers": "Customer Management",
  "/reports": "Reports & Analytics",
  "/settings": "Settings"
};

export default function Header() {
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  const pageName = pageNames[location as keyof typeof pageNames] || "Page";

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4 flex-1">
          <h2 className="text-2xl font-bold text-gray-900">{pageName}</h2>
          
          {/* Global Search */}
          <div className="relative flex-1 max-w-md">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-gray-400" />
            </div>
            <Input
              type="text"
              placeholder="Search medicines, customers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Alerts and Actions */}
        <div className="flex items-center space-x-4">
          {/* Notifications */}
          <Button variant="ghost" size="sm" className="relative">
            <Bell className="h-5 w-5" />
            <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-alert-red"></span>
          </Button>

          {/* Quick Actions */}
          <Button className="bg-medical-green hover:bg-green-700">
            <Plus className="h-4 w-4 mr-2" />
            Quick Sale
          </Button>
        </div>
      </div>
    </header>
  );
}
