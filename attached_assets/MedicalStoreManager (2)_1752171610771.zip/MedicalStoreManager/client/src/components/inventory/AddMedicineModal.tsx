import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertMedicineSchema, type InsertMedicine } from "@shared/schema";

interface AddMedicineModalProps {
  open: boolean;
  onClose: () => void;
}

const categories = [
  "tablets",
  "capsules", 
  "syrups",
  "injections",
  "external",
  "supplements",
  "drops",
  "inhalers"
];

export default function AddMedicineModal({ open, onClose }: AddMedicineModalProps) {
  const { toast } = useToast();
  
  const form = useForm<InsertMedicine>({
    resolver: zodResolver(insertMedicineSchema),
    defaultValues: {
      name: "",
      genericName: "",
      manufacturer: "",
      category: "",
      dosage: "",
      price: "",
      costPrice: "",
      stock: 0,
      minStock: 10,
      barcode: "",
      expiryDate: new Date(),
      batchNumber: "",
      description: ""
    }
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertMedicine) => {
      return apiRequest("POST", "/api/medicines", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/medicines"] });
      toast({
        title: "Success",
        description: "Medicine added successfully",
      });
      onClose();
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add medicine",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertMedicine) => {
    createMutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add New Medicine</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Medicine Name *</Label>
              <Input
                id="name"
                {...form.register("name")}
                placeholder="e.g. Paracetamol 500mg"
              />
              {form.formState.errors.name && (
                <p className="text-sm text-red-600">{form.formState.errors.name.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="genericName">Generic Name</Label>
              <Input
                id="genericName"
                {...form.register("genericName")}
                placeholder="e.g. Acetaminophen"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="manufacturer">Manufacturer *</Label>
              <Input
                id="manufacturer"
                {...form.register("manufacturer")}
                placeholder="e.g. PharmaCorp"
              />
              {form.formState.errors.manufacturer && (
                <p className="text-sm text-red-600">{form.formState.errors.manufacturer.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Category *</Label>
              <Select onValueChange={(value) => form.setValue("category", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category.charAt(0).toUpperCase() + category.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {form.formState.errors.category && (
                <p className="text-sm text-red-600">{form.formState.errors.category.message}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="dosage">Dosage/Strength *</Label>
              <Input
                id="dosage"
                {...form.register("dosage")}
                placeholder="e.g. 500mg, 100ml"
              />
              {form.formState.errors.dosage && (
                <p className="text-sm text-red-600">{form.formState.errors.dosage.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="batchNumber">Batch Number *</Label>
              <Input
                id="batchNumber"
                {...form.register("batchNumber")}
                placeholder="e.g. PC001"
              />
              {form.formState.errors.batchNumber && (
                <p className="text-sm text-red-600">{form.formState.errors.batchNumber.message}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="price">Selling Price *</Label>
              <Input
                id="price"
                type="number"
                step="0.01"
                {...form.register("price")}
                placeholder="0.00"
              />
              {form.formState.errors.price && (
                <p className="text-sm text-red-600">{form.formState.errors.price.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="costPrice">Cost Price *</Label>
              <Input
                id="costPrice"
                type="number"
                step="0.01"
                {...form.register("costPrice")}
                placeholder="0.00"
              />
              {form.formState.errors.costPrice && (
                <p className="text-sm text-red-600">{form.formState.errors.costPrice.message}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="stock">Current Stock *</Label>
              <Input
                id="stock"
                type="number"
                {...form.register("stock", { valueAsNumber: true })}
                placeholder="0"
              />
              {form.formState.errors.stock && (
                <p className="text-sm text-red-600">{form.formState.errors.stock.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="minStock">Minimum Stock *</Label>
              <Input
                id="minStock"
                type="number"
                {...form.register("minStock", { valueAsNumber: true })}
                placeholder="10"
              />
              {form.formState.errors.minStock && (
                <p className="text-sm text-red-600">{form.formState.errors.minStock.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="expiryDate">Expiry Date *</Label>
              <Input
                id="expiryDate"
                type="date"
                {...form.register("expiryDate", { 
                  setValueAs: (value) => new Date(value) 
                })}
              />
              {form.formState.errors.expiryDate && (
                <p className="text-sm text-red-600">{form.formState.errors.expiryDate.message}</p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="barcode">Barcode</Label>
            <Input
              id="barcode"
              {...form.register("barcode")}
              placeholder="e.g. 123456789001"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              {...form.register("description")}
              placeholder="Additional information about the medicine"
              rows={3}
            />
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={createMutation.isPending}
              className="bg-medical-green hover:bg-green-700"
            >
              {createMutation.isPending ? "Adding..." : "Add Medicine"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
