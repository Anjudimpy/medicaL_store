import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { User, CreditCard, DollarSign, Receipt } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/utils";
import { insertSaleSchema, type Medicine, type Customer } from "@shared/schema";
import { z } from "zod";

interface CartItem {
  medicine: Medicine;
  quantity: number;
  total: number;
}

interface SaleModalProps {
  cart: CartItem[];
  total: number;
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

const saleFormSchema = insertSaleSchema.extend({
  discount: z.string().optional(),
  customerType: z.enum(["existing", "walk-in"]),
});

type SaleFormData = z.infer<typeof saleFormSchema>;

const paymentMethods = [
  "cash",
  "credit_card",
  "debit_card",
  "insurance",
  "bank_transfer"
];

export default function SaleModal({ cart, total, open, onClose, onSuccess }: SaleModalProps) {
  const [customerType, setCustomerType] = useState<"existing" | "walk-in">("walk-in");
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [customerSearch, setCustomerSearch] = useState("");
  const { toast } = useToast();

  const { data: customers = [] } = useQuery({
    queryKey: ["/api/customers"],
  });

  const { data: searchResults = [] } = useQuery({
    queryKey: ["/api/customers/search", customerSearch],
    enabled: customerSearch.length > 0 && customerType === "existing",
  });

  const form = useForm<SaleFormData>({
    resolver: zodResolver(saleFormSchema),
    defaultValues: {
      customerId: undefined,
      customerName: "",
      totalAmount: total.toString(),
      discount: "0",
      finalAmount: total.toString(),
      paymentMethod: "cash",
      customerType: "walk-in"
    }
  });

  // Watch discount to calculate final amount
  const discount = form.watch("discount");
  const discountAmount = parseFloat(discount || "0");
  const finalAmount = Math.max(0, total - discountAmount);

  // Update final amount when discount changes
  React.useEffect(() => {
    form.setValue("finalAmount", finalAmount.toString());
  }, [discount, total, finalAmount, form]);

  const saleMutation = useMutation({
    mutationFn: async (data: SaleFormData) => {
      const saleData = {
        customerId: customerType === "existing" && selectedCustomer ? selectedCustomer.id : undefined,
        customerName: customerType === "walk-in" ? data.customerName : selectedCustomer?.name,
        totalAmount: data.totalAmount,
        discount: data.discount || "0",
        finalAmount: data.finalAmount,
        paymentMethod: data.paymentMethod,
      };

      const saleItems = cart.map(item => ({
        medicineId: item.medicine.id,
        quantity: item.quantity,
        unitPrice: item.medicine.price,
        totalPrice: item.total.toString()
      }));

      return apiRequest("POST", "/api/sales", {
        sale: saleData,
        items: saleItems
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sales"] });
      queryClient.invalidateQueries({ queryKey: ["/api/medicines"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/dashboard"] });
      toast({
        title: "Success",
        description: "Sale completed successfully",
      });
      onSuccess();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to complete sale",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: SaleFormData) => {
    // Validate stock availability
    const insufficientStock = cart.find(item => item.quantity > item.medicine.stock);
    if (insufficientStock) {
      toast({
        title: "Insufficient Stock",
        description: `${insufficientStock.medicine.name} has insufficient stock`,
        variant: "destructive",
      });
      return;
    }

    if (customerType === "walk-in" && !data.customerName?.trim()) {
      toast({
        title: "Customer Name Required",
        description: "Please enter customer name for walk-in sale",
        variant: "destructive",
      });
      return;
    }

    if (customerType === "existing" && !selectedCustomer) {
      toast({
        title: "Customer Required",
        description: "Please select a customer for existing customer sale",
        variant: "destructive",
      });
      return;
    }

    saleMutation.mutate(data);
  };

  const displayCustomers = customerSearch ? searchResults : customers.slice(0, 10);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Receipt className="h-5 w-5 mr-2" />
            Complete Sale
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Sale Items Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {cart.map((item) => (
                  <div key={item.medicine.id} className="flex justify-between items-center py-2 border-b border-gray-100 last:border-b-0">
                    <div className="flex-1">
                      <p className="font-medium text-sm">{item.medicine.name}</p>
                      <p className="text-xs text-gray-500">{item.medicine.dosage}</p>
                      <p className="text-xs text-gray-600">
                        {item.quantity} × {formatCurrency(item.medicine.price)}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{formatCurrency(item.total)}</p>
                      <Badge variant="outline" className="text-xs">
                        Stock: {item.medicine.stock}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
              
              <Separator className="my-4" />
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>{formatCurrency(total)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Discount:</span>
                  <span>-{formatCurrency(discountAmount)}</span>
                </div>
                <Separator />
                <div className="flex justify-between text-lg font-bold">
                  <span>Total:</span>
                  <span>{formatCurrency(finalAmount)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Sale Form */}
          <Card>
            <CardHeader>
              <CardTitle>Sale Details</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                {/* Customer Type Selection */}
                <div className="space-y-2">
                  <Label>Customer Type</Label>
                  <Select 
                    value={customerType} 
                    onValueChange={(value: "existing" | "walk-in") => {
                      setCustomerType(value);
                      setSelectedCustomer(null);
                      form.setValue("customerType", value);
                      form.setValue("customerId", undefined);
                      form.setValue("customerName", "");
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="walk-in">Walk-in Customer</SelectItem>
                      <SelectItem value="existing">Existing Customer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Customer Selection/Input */}
                {customerType === "walk-in" ? (
                  <div className="space-y-2">
                    <Label htmlFor="customerName">Customer Name *</Label>
                    <div className="flex items-center space-x-2">
                      <User className="h-4 w-4 text-gray-400" />
                      <Input
                        id="customerName"
                        {...form.register("customerName")}
                        placeholder="Enter customer name"
                        className="flex-1"
                      />
                    </div>
                    {form.formState.errors.customerName && (
                      <p className="text-sm text-red-600">{form.formState.errors.customerName.message}</p>
                    )}
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Select Customer *</Label>
                    <div className="space-y-2">
                      <Input
                        placeholder="Search customers..."
                        value={customerSearch}
                        onChange={(e) => setCustomerSearch(e.target.value)}
                      />
                      
                      {selectedCustomer ? (
                        <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="font-medium">{selectedCustomer.name}</p>
                              <p className="text-sm text-gray-500">{selectedCustomer.phone}</p>
                              <p className="text-sm text-gray-500">{selectedCustomer.email}</p>
                            </div>
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setSelectedCustomer(null);
                                form.setValue("customerId", undefined);
                              }}
                            >
                              Change
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="max-h-32 overflow-y-auto border rounded-lg">
                          {displayCustomers.map((customer: Customer) => (
                            <div
                              key={customer.id}
                              className="p-2 hover:bg-gray-50 cursor-pointer border-b last:border-b-0"
                              onClick={() => {
                                setSelectedCustomer(customer);
                                form.setValue("customerId", customer.id);
                                setCustomerSearch("");
                              }}
                            >
                              <p className="font-medium text-sm">{customer.name}</p>
                              <p className="text-xs text-gray-500">{customer.phone}</p>
                            </div>
                          ))}
                          
                          {displayCustomers.length === 0 && (
                            <p className="p-4 text-gray-500 text-sm text-center">
                              {customerSearch ? "No customers found" : "No customers available"}
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Payment Method */}
                <div className="space-y-2">
                  <Label>Payment Method *</Label>
                  <Select onValueChange={(value) => form.setValue("paymentMethod", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select payment method" />
                    </SelectTrigger>
                    <SelectContent>
                      {paymentMethods.map((method) => (
                        <SelectItem key={method} value={method}>
                          <div className="flex items-center space-x-2">
                            <CreditCard className="h-4 w-4" />
                            <span>{method.replace("_", " ").toUpperCase()}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {form.formState.errors.paymentMethod && (
                    <p className="text-sm text-red-600">{form.formState.errors.paymentMethod.message}</p>
                  )}
                </div>

                {/* Discount */}
                <div className="space-y-2">
                  <Label htmlFor="discount">Discount Amount</Label>
                  <div className="flex items-center space-x-2">
                    <DollarSign className="h-4 w-4 text-gray-400" />
                    <Input
                      id="discount"
                      type="number"
                      step="0.01"
                      min="0"
                      max={total}
                      {...form.register("discount")}
                      placeholder="0.00"
                      className="flex-1"
                    />
                  </div>
                  {discountAmount > total && (
                    <p className="text-sm text-red-600">Discount cannot exceed total amount</p>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex justify-end space-x-2 pt-4">
                  <Button type="button" variant="outline" onClick={onClose}>
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={saleMutation.isPending || discountAmount > total}
                    className="bg-medical-green hover:bg-green-700"
                  >
                    {saleMutation.isPending ? "Processing..." : `Complete Sale ${formatCurrency(finalAmount)}`}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}
