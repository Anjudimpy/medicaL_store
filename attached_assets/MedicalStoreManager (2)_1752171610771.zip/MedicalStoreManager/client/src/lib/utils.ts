import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: string | number): string {
  const num = typeof amount === 'string' ? parseFloat(amount) : amount;
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(num);
}

export function formatDate(date: string | Date): string {
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  }).format(new Date(date));
}

export function formatDateTime(date: string | Date): string {
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  }).format(new Date(date));
}

export function isExpiringSoon(expiryDate: string | Date, days: number = 30): boolean {
  const expiry = new Date(expiryDate);
  const today = new Date();
  const diffTime = expiry.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays <= days && diffDays >= 0;
}

export function isExpired(expiryDate: string | Date): boolean {
  const expiry = new Date(expiryDate);
  const today = new Date();
  return expiry < today;
}

export function getDaysUntilExpiry(expiryDate: string | Date): number {
  const expiry = new Date(expiryDate);
  const today = new Date();
  const diffTime = expiry.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

export function getStockStatus(stock: number, minStock: number): 'out' | 'low' | 'normal' {
  if (stock === 0) return 'out';
  if (stock <= minStock) return 'low';
  return 'normal';
}

export function getStockStatusColor(status: 'out' | 'low' | 'normal'): string {
  switch (status) {
    case 'out': return 'text-alert-red';
    case 'low': return 'text-warning-orange';
    case 'normal': return 'text-green-600';
  }
}
